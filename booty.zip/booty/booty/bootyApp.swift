//
//  bootyApp.swift
//  booty
//
//  Created by Tech on 2025-03-21.
//

import SwiftUI

@main
struct BootyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView() 
        }
    }
}
